
def getcolor():
	return "black"

clips.RegisterPythonFunction(getcolor)
clips.BuildFunction("get-color", "", "(python-call getcolor)")
